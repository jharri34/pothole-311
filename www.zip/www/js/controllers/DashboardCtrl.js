/**
 * @ngdoc object
 * @name DashboardCtrl
 * @requires $scope
 * @requires $DataFactory
 * @description
 *
 * Controller for Dashboard
 * - retrieves data from DataFactory and sets data to scope
 * -
 *
 */
angular.module('peace-m.controllers')
    .controller('DashboardCtrl', ['$scope',
        function ($scope) {
        }]);